import {Router} from 'express'
import { getUsuarios, getRecetas, createRecetas, createUsuarios, getUsuariosById, getRecetasById} from '../controllers/products.controllers'
const router = Router()
router.get('/usuarios', getUsuarios)
router.post('/usuarios',createUsuarios)
router.get('/usuarios:id', getUsuariosById)
router.delete('/usuarios', )
router.put('/usuarios', )
/////////////////////////////////////////////////////////////////////////
router.get('/recetas', getRecetas)
router.post('/recetas',createRecetas)
router.get('/recetas:id', getRecetasById)
router.delete('/recetas', )
router.put('/recetas', )

export default router