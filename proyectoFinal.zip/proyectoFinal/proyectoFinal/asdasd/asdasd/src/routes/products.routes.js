import {Router} from 'express'
import { getUsuarios, getRecetas, createRecetas, createUsuarios, getUsuariosById, getRecetasById, deleteRecetasById, deleteUsuarioById} from '../controllers/products.controllers'
const router = Router()
router.get('/usuarios', getUsuarios)
router.post('/usuarios',createUsuarios)
router.get('/usuarios/:idUsuario', getUsuariosById)
router.delete('/usuarios/:idUsuario', deleteUsuarioById)
router.put('/usuarios', )
/////////////////////////////////////////////////////////////////////////
router.get('/recetas', getRecetas)
router.post('/recetas',createRecetas)
router.get('/recetas/:idRecetas', getRecetasById)
router.delete('/recetas/:idRecetas', deleteRecetasById)
router.put('/recetas', )

export default router