import {Router} from 'express'
import { getUsuarios, getRecetas, createRecetas, createUsuarios} from '../controllers/products.controllers'
const router = Router()
router.get('/usuarios', getUsuarios)
router.post('/usuarios',createUsuarios)
router.get('/usuarios', )
router.delete('/usuarios', )
router.put('/usuarios', )
/////////////////////////////////////////////////////////////////////////
router.get('/recetas', getRecetas)
router.post('/recetas',createRecetas)
router.get('/recetas', )
router.delete('/recetas', )
router.put('/recetas', )

export default router