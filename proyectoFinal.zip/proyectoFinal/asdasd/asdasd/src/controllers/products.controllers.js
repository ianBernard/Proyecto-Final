import { getConnection } from "../database/connection"
export const getUsuarios = async (req, res)=>{
    const pool = await getConnection()
    const result = await pool.request().query('select * from Usuarios')
    res.json(result.recordset)
}
export const createUsuarios = async (req, res)=>{
    const {usuario,contraseña} = req.body
    if (usuario==null||contraseña==null) {
        return res.status(400).json(msg='Por favor llene los espacios')
    }
    res.json("Nuevo Usuario")
}
/////////////////////////////////////////////////////////////////////////

export const getRecetas = async (req, res)=>{
    const pool = await getConnection()
    const result = await pool.request().query('select * from Receta')
    res.json(result.recordset)
}
export const createRecetas = async (req, res)=>{
    const {NombreReceta,upvotes,downvotes,visitas,descripcios} = req.body
    if (NombreReceta==null||descripcios==null) {
        return res.status(400).json(msg='Por favor llene los espacios')
    }
    if (upvotes==null||downvotes==null||visitas==null) {
        upvotes==0
        downvotes==0
        visitas==0
    }
    
    res.json("Nueva Receta")
}