export const queries = {
    ////////////USUARIOS
    getAllUsuarios:"select * from Usuarios",
    createUsuarios: "INSERT INTO Usuarios (usuario,contraseña) VALUES (@usuario,@contraseña)",
    getUsuariosById:"SELECT * FROM Usuarios Where idUsuario = @idUsuario",
    deleteUsuario:"DELETE FROM Usuarios Where idUsuario = @idUsuario",
/////////////////RECETAS
    getAllRecetas:"select * from Receta",
    createRecetas:"INSERT INTO Receta (NombreReceta,upvotes,downvotes,visitas,descripcios) VALUES (@NombreReceta,@upvotes,@downvotes,@visitas,@descripcios)",
    getRecetasById:"SELECT * FROM Receta Where idReceta = @idReceta",
    deleteReceta:"DELETE FROM Receta Where idReceta = @idReceta",   
    ///////////RUTINAS
    getAllRutina:"select * from Rutina",
}