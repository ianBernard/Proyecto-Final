import {Router} from 'express'
const router = Router()
router.get('/usuarios', (req, res)=> res.send('aniquilamiento de gays'))
export default router