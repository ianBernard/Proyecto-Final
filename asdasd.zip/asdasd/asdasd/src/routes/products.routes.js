import {Router} from 'express'
import { getUsuarios, putUsuarios } from '../controllers/products.controllers'
const router = Router()
router.get('/usuarios', getUsuarios)
router.post('/usuarios', putUsuarios)
router.get('/usuarios', )
router.delete('/usuarios', )
router.put('/usuarios', )

export default router