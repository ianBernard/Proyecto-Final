import { getConnection } from "../database/connection"
export const getUsuarios = async (req, res)=>{
    const pool = await getConnection()
    const result = await pool.request().query('select * from Usuarios')
    res.json(result.recordset)
}
export const putUsuarios = async (req, res)=>{
    res.json('new product')
}