CREATE DATABASE IF NOT EXISTS tasksdb;
USE tasksdb;
CREATE TABLE IF NOT EXISTS taks(
    id INT NOT NULL AUTO_INCREMENT,
    titles VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    PRIMARY KEY (id)
);

INSERT INTO taks (titles, description) VALUES
    ('task 1', 'some description'),
    ('task 2', 'some description 2');
