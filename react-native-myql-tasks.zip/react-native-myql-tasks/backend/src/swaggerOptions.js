export const options = {
    definition: {
        info: {
            title: 'task api'
        }
    },
    apis:['./src/routes/**/*.js']
}