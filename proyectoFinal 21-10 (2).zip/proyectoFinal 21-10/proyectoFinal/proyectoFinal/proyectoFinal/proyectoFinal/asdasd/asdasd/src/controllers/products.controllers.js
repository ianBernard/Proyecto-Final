import { getConnection, sql, queries } from "../database/"

export const getUsuarios = async (req, res)=>{
   try{ const pool = await getConnection()
    const result = await pool.request().query(queries.getAllUsuarios)
    res.json(result.recordset)
    }catch(error){
        res.status(500)
        res.send(error.msg)
    }
}
export const createUsuarios = async (req, res)=>{
    const {Usuario,Contraseña} = req.body
    if (Usuario==null||Contraseña==null) {
        return res.status(400).json(msg='Por favor llene los espacios')
    }
    try{    
    const pool =await getConnection()
    await pool.request().input("Usuario", sql.Text, Usuario).input("Contraseña",sql.Text,Contraseña).query(queries.createUsuarios)
    res.json({Usuario, Contraseña})
        }catch(error){
            res.status(500)
            res.send(error.msg)
        }

}

export const getUsuariosById= async (req, res) =>{
    const {IdUsuario}=req.params
    const pool =await getConnection()
    const result = await pool.request().input('IdUsuario', IdUsuario).query(queries.getUsuariosById)
    console.log(result)
    res.send(IdUsuario)
}
export const deleteUsuarioById = async (req, res) =>{
    const {IdUsuario} = req.params
    const pool =await getConnection()
    const result= await pool.request().input('IdUsuario', IdUsuario).query(queries.deleteUsuario)
    console.log(result)
    res.send(IdUsuario)
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

export const getRecetas = async (req, res)=>{
    try{ 
        const pool = await getConnection()
        const result = await pool.request().query(queries.getAllRecetas)
        res.json(result.recordset)
        }catch(error){
            res.status(500)
            res.send(error.msg)
        }

}
export const createRecetas = async (req, res)=>{
    const {Foto,Nombre,Descripcion,PasoAPaso,TiempoDeCocina} = req.body
        let {IdUsuario, Upvotes, Downvotes, Visitas }=req.body
        if (Foto==null||Nombre==null||Descripcion==null||PasoAPaso==null||TiempoDeCocina==null) {
            return res.status(400).json(msg='Por favor llene los espacios')
        }
        if (IdUsuario==null||Upvotes==null||Downvotes==null||Descripcion==null||Visitas==null) {
            IdUsuario==0
            Upvotes==0
            Descripcion==0
            PasoAPaso==0
            Visitas==0
        }
        try{ 
        const pool =await getConnection()
        await pool
        await pool.request().input("IdUsuario", sql.Text, IdUsuario).input("Foto", sql.Int, Foto).input("Nombre", sql.Int, Nombre).input("Descripcion", sql.Int, Descripcion).input("PasoAPaso", sql.Text, PasoAPaso).input("TiempoDeCocina", sql.Text, TiempoDeCocina).input("Upvotes", sql.Text, Upvotes).input("Downvotes", sql.Text, Downvotes).input("Visitas", sql.Text, Visitas).query(queries.createRecetas)
        res.json({IdUsuario,Foto,Nombre,Descripcion,PasoAPaso,TiempoDeCocina,Upvotes,Downvotes,Visitas})
        }catch(error){
            res.status(500)
            res.send(error.msg)
        }

}

export const getRecetasById = async (req, res) =>{
    const {idReceta} = req.params
    const pool =await getConnection()
    const result= await pool.request().input('IdRecetas', IdRecetas).query(queries.getRecetasById)
    console.log(result)
    res.send(idReceta)
}

export const deleteRecetasById = async (req, res) =>{
    const {idReceta} = req.params
    const pool =await getConnection()
    const result2= await pool.request().input('IdRecetas', IdRecetas).query(queries.deleteReceta)
    console.log(result2)
    res.send(result2)
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
export const getRutinas = async (req, res)=>{
    try{ 
        const pool = await getConnection()
        const result = await pool.request().query(queries.getAllRutinas)
        res.json(result.recordset)
        }catch(error){
            res.status(500)
            res.send(error.msg)
        }
}

export const createRutinas = async (req, res)=>{
    const {Foto, Descripcion, Nombre, MusculosEjercitados} = req.body
        let {IdUsuario, Series, Repeticiones,Upvotes , Downvotes, Visitas }=req.body
        if (Foto==null||Nombre==null||Descripcion==null||MusculosEjercitados==null) {
            return res.status(400).json(msg='Por favor llene los espacios')
        }
        if (IdUsuario==null||Series==null||Repeticiones==null||Upvotes==null||Downvotes==null||Visitas==null) {
            IdUsuario==0
            Series==0
            Repeticiones==0
            Upvotes==0
            Downvotes==0
            Visitas==0
        }
        try{ 
        const pool =await getConnection()
        await pool
        await pool.request().input("IdUsuario", sql.Int, IdUsuario).input("Foto", sql.Text, Foto).input("Descripcion", sql.Text, Descripcion).input("Series", sql.Text, Series).input("Repeticiones", sql.Text, Repeticiones).input("Nombre", sql.Text, Nombre).input("MusculosEjercitados", sql.Text, MusculosEjercitados).input("Upvotes", sql.Int, Upvotes).input("Downvotes", sql.Int, Downvotes).input("Visitas", sql.Int, Visitas).query(queries.createRutinas)
        res.json({IdUsuario,Foto,Descripcion,Nombre,MusculosEjercitados,Series,Repeticiones,Upvotes,Downvotes,Visitas})
        }catch(error){
            res.status(500)
            res.send(error.msg)
        }
        
}
export const getRutinasById = async (req, res) =>{
    const {IdRutinas} = req.params
    const pool =await getConnection()
    const result= await pool.request().input('IdRutinas', IdRutinas).query(queries.getRutinasById)
    console.log(result)
    res.send(result)
}

export const deleteRutinasById = async (req, res) =>{
    const {IdRutinas} = req.params
    const pool =await getConnection()
    const result2= await pool.request().input('IdRutinas', IdRutinas).query(queries.deleteRutinas)
    console.log(result2)
    res.send(result2)
}