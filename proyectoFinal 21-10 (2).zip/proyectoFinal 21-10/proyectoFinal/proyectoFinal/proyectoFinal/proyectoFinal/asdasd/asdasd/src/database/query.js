import { createUsuarios, getUsuariosById } from "../controllers/products.controllers";

export const queries = {
    getAllUsuarios:"select * from Usuarios",
    createUsuarios: "INSERT INTO Usuarios (Usuario,Contraseña) VALUES (@Usuario,@Contraseña)",
    getUsuariosById:"SELECT * FROM Usuarios Where IdUsuario = @IdUsuario",
    deleteUsuario:"DELETE FROM Usuarios Where IdUsuario = @IdUsuario",
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    getAllRecetas:"select * from Recetas",
    createRecetas:"INSERT INTO Recetas (IdUsuario,Foto,Nombre,Descripcion,PasoAPaso,TiempoDeCocina,Visitas) VALUES (@IdUsuario,@Foto,@Nombre,@Descripcion,@PasoAPaso,@TiempoDeCocina, @Visitas)",
    getRecetasById:"SELECT * FROM Recetas Where IdRecetas = @IdRecetas",
    deleteReceta:"DELETE FROM Recetas Where IdRecetas = @IdRecetas",   
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    getAllRutinas:"select * from Rutinas",
    createRutinas:"INSERT INTO Rutinas (IdUsuario,Foto,Descripcion,Nombre,MusculosEjercitados,Series,Repeticiones,Upvotes,Downvotes,Visitas) VALUES (@IdUsuario,@Foto,@Descripcion,@Nombre,@MusculosEjercitados,@Series,@Repeticiones,@Upvotes,@Downvotes,@Visitas)",
    getRutinasById:"SELECT * FROM Rutinas Where IdRutinas = @IdRutinas",
    deleteRutinas:"DELETE FROM Rutinas Where IdRutinas = @IdRutinas",  
}